########################################################################
# Written by     : Gurdyal Singh
# Written on     : April 29, '2016
# Description    : Pretty Print a JSON file into another FILE or STRING
#                  Input DATA File is in CSV format
#                  Header contains the KEYS of DICTIONARY
#                  and rest of the rows are VALUE of DICTIONARY'ies
#                  MongoDB expects each RECORD as DICTIONARY on SINGLE row
#                  This PYTHON program tries to convert this INPUT CSV
#                  file in a JSON format acceptable for use with MongoDB
#                  tool mongoimport
#                  Convert a list of Values into MongoDB JSON format
# Completed on   : April XX, '2016
# Total Days     : Approximately XX Hours
########################################################################


import csv
import json





Ifile="Blood_bank_updated-sep_2015_from_____XLS.csv"
Ofile="BB_csvDict_test.json"

o_fhand = open( Ofile, 'w' )

with open ( Ifile ) as f:
  # csv.DictReader(FILE, quoting = csv.QUOTE_NONNUMERIC, QUOTE_ALL, QUOTE_MINIMAL, QUOTE_NONE)

  reader = csv.DictReader ( f )

  # print "\nFieldsnames :", reader.fieldnames, "\n\n"
  reader.fieldnames[0] = "_id"
  # print "\nFieldsnames :", reader.fieldnames, "\n\n"

  var_i=0
  for row in reader:
    print (var_i, row), type(row)
    if var_i < 22: json.dump( row, o_fhand )
    # json.dump( row, o_fhand, indent=0 )
    # raw_input("\n\nEnter : ")
    var_i+=1



