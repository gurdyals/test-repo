########################################################################
# Written by     : Gurdyal Singh
# Written on     : April 20, '2016
# Description    : Pretty Print a JSON file into another FILE or STRING
#                  Input DATA File is in CSV format
#                  Header contains the KEYS of DICTIONARY
#                  and rest of the rows are VALUE of DICTIONARY'ies
#                  MongoDB expects each RECORD as DICTIONARY on SINGLE row
#                  This PYTHON program tries to convert this INPUT CSV
#                  file in a JSON format acceptable for use with MongoDB
#                  tool mongoimport
#                  Convert a list of Values into MongoDB JSON format
# Completed on   : April 21, '2016
# Total Days     : Approximately 09 Hours
########################################################################

##### https://docs.python.org/2/library/functions.html#open
##### open(name[, mode[, buffering]]) # ( mode = 'r', 'w', 'a' ), ( buffering = ( '0', '1' )
##### The optional buffering argument specifies the file's desired buffer size: 0 means unbuffered, 1 means line buffered, any other positive value means use a buffer of (approximately) that size (in bytes). A negative buffering means to use the system default, which is usually line buffered for tty devices and fully buffered for other files. If omitted, the system default is used
##### https://docs.python.org/2/library/functions.html#map
##### map(function, iterable, ...);
##### https://docs.python.org/2/library/functions.html#zip
##### zip([iterable, ...]);      zipped = zip(x, y);       x2, y2 = zip(*zipped);




import json  # This is for working on JSON data
import csv   # This is for working on .csv FILE



def is_number(str):
    try:
        float(str) #####       complex(str) --- test complex numbers like 1+2i
        return True
    except ValueError:
        return False



inp_FILE = "Blood_bank_updated-sep_2015_from_____XLS.csv"
out_FILE = "BB_MongoDB_int.json"

print "inp_FILE :", inp_FILE, "\nout_FILE :", out_FILE

fhand = open( inp_FILE, 'r' )
fhout = open( out_FILE, 'wb', buffering = 1 )

var_i = 0
keys = None
##### for line in fhand:
for line in csv.reader( fhand ):
  ##### line = line.rstrip().split(',')
  # print "LIST(line) : ", list(line), "\nSTR(line) :", str(line), "\nunicode(line) :", unicode(line), "\n\n"
  ##### if var_i == 0 && keys == None:
  if keys == None:
    keys = line;
    keys[0] = "_id";        #####  k = zip(*keys);
    continue;

  ##### for index in [ 0, 6, 16, 17 ]:
  if line[0].isdigit():
    line[0] = int( line[0] )

  if line[6].isdigit():
    line[6] = int( line[6] )

  if is_number( line[16] ):
    line[16] = float( line[16] )

  if is_number( line[17] ):
    line[17] = float( line[17] )


  zip1 = zip(keys, line)
  # map1 = map(None, keys, line)

  dict1 = dict(zip1)
  ##### print var_i, "\nKEYS :", keys, "\nLINE :", line, "\nZIP :", zip1, "\ndict1 :", dict1
  # print "\nMAP :", map1


  json.dump( dict1, fhout, sort_keys = True, indent = 0 )
  # raw_input()
  var_i += 1
