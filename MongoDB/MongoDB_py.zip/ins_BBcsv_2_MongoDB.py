########################################################################
# Written by     : Gurdyal Singh
# Written on     : April 21, '2016
# Description    : Input DATA File is in CSV format
#                  Header contains the KEYS of DICTIONARY
#                  and rest of the rows are VALUE of DICTIONARY'ies
#                  This program inserts data from each row in MongoDB
# Completed on   : April 21, '2016
# Total Days     : Approximately 07 Hours
########################################################################

##### https://docs.python.org/2/library/functions.html#open
##### open(name[, mode[, buffering]]) # ( mode = 'r', 'w', 'a' ), ( buffering = ( '0', '1' )
##### The optional buffering argument specifies the file's desired buffer size: 0 means unbuffered, 1 means line buffered, any other positive value means use a buffer of (approximately) that size (in bytes). A negative buffering means to use the system default, which is usually line buffered for tty devices and fully buffered for other files. If omitted, the system default is used
##### https://docs.python.org/2/library/functions.html#map
##### map(function, iterable, ...);
##### https://docs.python.org/2/library/functions.html#zip
##### zip([iterable, ...]);      zipped = zip(x, y);       x2, y2 = zip(*zipped);




import pymongo    # This Module is used to intereact with the MongoDB DataBase
import json       # This is for working on JSON data
import csv        # This is for working on .csv FILE
import datetime   # This Module is used for datetime Operations/Functions


# https://docs.python.org/2/library/datetime.html#strftime-strptime-behavior
# strftime(); and strptime();  Behaviour

__author__ = 'gs'

def is_number(str):
    try:
        float(str);
        return True
    except ValueError:
        return False

record0 = { "_id" : 0, "Description" : "This is the Data of Blood Banks in India taken from the OPEN DATA website data.gov.in on April 12th, '2016 for various ETL and Data Analysis" }



# Various Options to connect to MongoClient and Collection
# client = MongoClient();
# client = MongoClient('localhost', 27017);
# client = MongoClient('mongodb://localhost:27017/');
# db = client.test_database;
# db = client['test-database'];


# Connect to the MongoDB DataBase on localhost to the DataBase=DB
connection_string = "mongodb://localhost:27017/";
connection        = pymongo.MongoClient( connection_string );
# DataBase to be used = "DB"
database          = connection.DB;
# Collection Name
blood_bank        = database.blood_bank

# dt = datetime.datetime.now()
# coll  = "bb_" + dt.strftime("%Y%m%d")
coll  = "bb_" + datetime.datetime.now().strftime("%Y%m%d")
print "coll : ", coll
col               = database[coll]


# col.drop()
# print "Collection : ", col, " is dropped"
##### raw_input('Please Enter to continue Further')



inp_FILE = "Blood_bank_updated-sep_2015_from_____XLS.csv"
out_FILE = "BB_MongoDB_int001.json"
print "inp_FILE :", inp_FILE, "\nout_FILE :", out_FILE



# use DataBase.collection_names() Function to get all the collections in the DataBase=database
var_coll = database.collection_names();
print "var_coll :", var_coll

var_i = 0
for coll in var_coll:
  var_i += 1
  print var_i, ") Collection No. ", var_i, " : ", coll
##### raw_input('Please Enter to continue Further')


fhand = open( inp_FILE, 'rb' )
# fhout = open( out_FILE, 'wb' )

# print "value of blood_bank : ", blood_bank, type(blood_bank)
# print "value of col : ", col, type(col)

# icur = blood_bank.find({ })
icur = col.find({ })
icur.sort( '_id', pymongo.ASCENDING )

var_i = 0
for record in icur:
  print var_i, "record :", record
  var_i += 1
##### raw_input('Please Enter to continue Further')




var_i = 0
keys = None
for line in csv.reader( fhand ):
  if keys == None:
    keys = line;
    keys[0] = "_id";
    try:
      ##### col.insert_one( record0, bypass_document_validation = True );
      col.insert_one( record0 )
    # Next 2 lines are catch DuplicateKeyError
    except pymongo.errors.DuplicateKeyError as e:
      print "DuplicateKeyError for _id :", record0['_id']

    continue;

  if line[0].isdigit():
      line[0] = int( line[0] );
  if line[6].isdigit():
      line[6] = int( line[6] );
  if is_number( line[16] ):
      line[16] = float( line[16] );
  if is_number( line[17] ):
      line[17] = float( line[17] );


  zip1 = zip(keys, line)
  dict1 = dict(zip1)


  print "dict1 :", dict1
#   col.insert_one( dict1, bypass_document_validation = True );

  try:
    col.insert_one( dict1, bypass_document_validation = True );
  # Next TWO lines are catch_all exceptions
  ##### except Exception as e:
    ##### print "Unexpected error:", type(e), e

  # Next 2 lines are catch DuplicateKeyError
  except pymongo.errors.DuplicateKeyError as e:
    print "DuplicateKeyError for _id :", dict1['_id']

  var_i += 1
##### raw_input('Please Enter to continue Further')




icur = col.find({ })
icur.sort( '_id', pymongo.ASCENDING )

var_i = 0
for doc in icur:
  print var_i, "doc :", doc
  var_i += 1
##### raw_input('Please Enter to continue Further')
